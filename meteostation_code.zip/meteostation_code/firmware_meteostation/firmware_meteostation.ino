// ============================================================
// Автономная метеостанция на ESP32 + BME280
// Цикл: глубокий сон (15 мин) -> измерение -> фильтрация
//       -> отправка по HTTP POST -> снова сон
// ============================================================

#include <WiFi.h>
#include <HTTPClient.h>
#include <Adafruit_BME280.h>
#include "time.h"

// ---------- Настройки Wi-Fi ----------
const char* WIFI_SSID     = "YOUR_SSID";
const char* WIFI_PASSWORD = "YOUR_PASSWORD";

// ---------- Настройки сервера ----------
const char* SERVER_URL = "http://192.168.1.100:5000/api/weather";

// ---------- Пины и константы ----------
#define BAT_ADC_PIN   34        // аналоговый вход (делитель R1=27к, R2=100к)
#define BAT_DIV_RATIO 0.787     // R2 / (R1 + R2)

#define SLEEP_MINUTES 15        // период замера (для отладки поставьте 1)
#define READINGS_TO_AVG 5       // усреднение по 5 замерам
#define TEMP_JUMP_LIMIT 5.0     // порог выброса температуры, °C
#define HUM_JUMP_LIMIT 10.0     // порог выброса влажности, %
#define WIFI_TIMEOUT_MS 15000   // максимум на подключение к Wi-Fi

// Последнее отправленное значение (сохраняется в RTC-памяти во сне)
RTC_DATA_ATTR float lastTemp = NAN;
RTC_DATA_ATTR float lastHum  = NAN;

Adafruit_BME280 bme;

// ------------------------------------------------------------
// Подключение к Wi-Fi с таймаутом
// ------------------------------------------------------------
bool connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED) {
    if (millis() - start > WIFI_TIMEOUT_MS) return false;
    delay(200);
  }
  return true;
}

// ------------------------------------------------------------
// Чтение напряжения батареи с усреднением
// ------------------------------------------------------------
float readBatteryVoltage() {
  // Несколько замеров для стабильности ADC
  uint32_t sum = 0;
  for (int i = 0; i < 10; i++) {
    sum += analogRead(BAT_ADC_PIN);
    delay(5);
  }
  float adcValue = sum / 10.0;
  // Внутреннее опорное ~1.1 В, разрешение 12 бит (0-4095)
  float voltage = (adcValue / 4095.0) * 1.1 / BAT_DIV_RATIO;
  return voltage;
}

// ------------------------------------------------------------
// Однократное чтение BME280 (с проверкой)
// ------------------------------------------------------------
bool readBME(float &t, float &h, float &p) {
  if (!bme.readTemperature(&t)) return false;
  h = bme.readHumidity();
  p = bme.readPressure() / 100.0F;  // перевод Па -> гПа
  return true;
}

// ------------------------------------------------------------
// Проверка выброса: значение не должно скакать сильнее порога
// ------------------------------------------------------------
bool isOutlier(float newVal, float lastVal, float limit) {
  if (isnan(lastVal)) return false;   // первое измерение — не выброс
  return fabs(newVal - lastVal) > limit;
}

// ------------------------------------------------------------
// Отправка данных на сервер
// ------------------------------------------------------------
bool sendData(float t, float h, float p, float bat) {
  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");

  // Формируем JSON вручную (не тянем тяжёлую библиотеку)
  char payload[256];
  snprintf(payload, sizeof(payload),
           "{\"temp\":%.2f,\"hum\":%.2f,\"pres\":%.2f,\"bat\":%.2f,\"uptime\":%lu}",
           t, h, p, bat, (unsigned long)(millis() / 1000));

  int code = http.POST(payload);
  http.end();
  return (code == 200);
}

// ------------------------------------------------------------
// Переход в глубокий сон на SLEEP_MINUTES минут
// ------------------------------------------------------------
void goToSleep() {
  esp_sleep_enable_timer_wakeup((uint64_t)SLEEP_MINUTES * 60ULL * 1000000ULL);
  esp_deep_sleep_start();   // после пробуждения setup() выполнится заново
}

// ------------------------------------------------------------
// Настройка при каждом пробуждении
// ------------------------------------------------------------
void setup() {
  Serial.begin(115200);

  // Инициализация датчика
  if (!bme.begin(0x76)) {              // адрес 0x76 или 0x77
    Serial.println("BME280 не найден!");
    goToSleep();                       // даже без датчика — не висим
  }
  bme.setSampling(Adafruit_BME280::MODE_FORCED,
                  Adafruit_BME280::SAMPLING_X1,  // температура
                  Adafruit_BME280::SAMPLING_X1,  // влажность
                  Adafruit_BME280::SAMPLING_X1,  // давление
                  Adafruit_BME280::FILTER_OFF);

  // 1. Измеряем с усреднением
  float t, h, p;
  float tSum = 0, hSum = 0, pSum = 0;
  int goodReadings = 0;

  for (int i = 0; i < READINGS_TO_AVG; i++) {
    if (readBME(t, h, p)) {
      tSum += t; hSum += h; pSum += p;
      goodReadings++;
    }
    delay(100);
  }

  if (goodReadings == 0) {
    Serial.println("Датчик не отвечает — спим дальше");
    goToSleep();
  }

  float avgT = tSum / goodReadings;
  float avgH = hSum / goodReadings;
  float avgP = pSum / goodReadings;

  // 2. Фильтрация выбросов
  if (isOutlier(avgT, lastTemp, TEMP_JUMP_LIMIT) ||
      isOutlier(avgH, lastHum,  HUM_JUMP_LIMIT)) {
    Serial.println("Выброс зафиксирован — значение не отправляем");
    goToSleep();
  }

  // 3. Читаем батарею
  float batV = readBatteryVoltage();

  // 4. Отправляем
  if (connectWiFi()) {
    bool ok = sendData(avgT, avgH, avgP, batV);
    Serial.println(ok ? "Данные отправлены" : "Ошибка отправки");
    WiFi.disconnect();
  } else {
    Serial.println("Wi-Fi недоступен — данные потеряны");
    // Расширение: здесь можно сохранить замер на microSD
  }

  // 5. Запоминаем значения для следующей проверки выбросов
  lastTemp = avgT;
  lastHum  = avgH;

  // 6. Засыпаем
  goToSleep();
}

void loop() {
  // Сюда никогда не попадаем — всё делается в setup()
}
