# ============================================================
# Простой сервер приёма данных метеостанции
# Запуск: pip install flask, затем python server.py
# Данные пишутся в CSV, просмотр — по адресу http://<ip>:5000
# ============================================================
import csv
import os
from datetime import datetime
from flask import Flask, request, jsonify, Response

app = Flask(__name__)
CSV_FILE = "weather_data.csv"

# Создаём файл с заголовками, если его нет
if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, "w", newline="") as f:
        csv.writer(f).writerow(
            ["timestamp", "temp", "hum", "pres", "bat"])

@app.route("/api/weather", methods=["POST"])
def receive():
    data = request.get_json(force=True)
    with open(CSV_FILE, "a", newline="") as f:
        csv.writer(f).writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            data.get("temp"), data.get("hum"),
            data.get("pres"), data.get("bat")])
    return jsonify(status="ok")

@app.route("/")
def view():
    # Отдаём содержимое CSV — можно смотреть в браузере
    with open(CSV_FILE) as f:
        return Response(f.read(), mimetype="text/plain")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
