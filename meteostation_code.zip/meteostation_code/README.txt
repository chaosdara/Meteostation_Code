МЕТЕОСТАНЦИЯ НА SOLAR-ПИТАНИИ — КОМПЛЕКТ КОДА
================================================

Состав архива:
1. firmware_meteostation/firmware_meteostation.ino — основная прошивка ESP32
2. server/server.py — сервер приёма данных (Python Flask)
3. i2c_scanner/i2c_scanner.ino — сканер I2C для поиска адреса датчика

Библиотеки для Arduino IDE (Library Manager):
- Adafruit BME280 Library
- Adafruit Unified Sensor

Порядок запуска:
1. Прошейте i2c_scanner — убедитесь, что датчик виден (адрес 0x76 или 0x77).
2. В server/server.py: установите Flask (pip install flask), запустите сервер,
   узнайте IP компьютера (ipconfig в Windows / ip a в Linux).
3. В прошивке впишите свои WIFI_SSID, WIFI_PASSWORD и IP в SERVER_URL.
4. Для отладки установите SLEEP_MINUTES = 1, после отладки верните 15.
5. Проверьте, что в CSV растут строки, а в мониторе порта — "Данные отправлены".

Важно:
- Переменные RTC_DATA_ATTR сохраняют значения во время глубокого сна.
- Для измерения тока используйте мультиметр в разрыве цепи питания.
- Точка расширения: локальное хранение на microSD при недоступном Wi-Fi.
