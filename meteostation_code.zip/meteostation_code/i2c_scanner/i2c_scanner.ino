// ============================================================
// Сканер I2C — найти адрес BME280 (0x76 или 0x77)
// Запустите один раз перед первым стартом основной прошивки
// ============================================================
#include <Wire.h>

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);   // SDA, SCL
  Serial.println("Сканирование шины I2C...");
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.printf("Найдено устройство: 0x%02X\n", addr);
    }
  }
  Serial.println("Сканирование завершено.");
}

void loop() {}
